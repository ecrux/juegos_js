# sencilloInventario
Un sencillo programa en Javascript sobre inventarios
